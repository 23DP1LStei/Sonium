# Projekts Sonium

## Ievads
###  Programma lauj reģistreties, atrast mūzikas albumus un novertet (1-10) tiem. Ir iespeja apskatit visus novertētus albumus, filtret tos un apskatit vertejumus no citiem lokaliem lietotajiem.

## Lietotaja interfeisa apraksts

## Funkciju apraksti
1) Reģistrešana
2) Mūzkikas albumu meklēšana
3) Iespeja novertet mūzikas albumus
4) Iespja atzimet mūzikas albumu ka "noklausits"
5) Apskatit vertejumus no citiem lokaliem lietotajiem